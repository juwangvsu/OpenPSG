from __future__ import annotations

from typing import TYPE_CHECKING, Any

__version__ = "0.1.0"

__all__ = [
    "PsgtrConfig",
    "PsgtrForPanopticSceneGraphGeneration",
    "PsgtrHungarianMatcher",
    "PsgtrLoss",
    "PsgtrOutput",
]

if TYPE_CHECKING:
    from .configuration_psgtr import PsgtrConfig
    from .loss import PsgtrHungarianMatcher, PsgtrLoss
    from .modeling_psgtr import (
        PsgtrForPanopticSceneGraphGeneration,
        PsgtrOutput,
    )


def __getattr__(name: str) -> Any:
    if name == "PsgtrConfig":
        from .configuration_psgtr import PsgtrConfig

        return PsgtrConfig
    if name in {"PsgtrHungarianMatcher", "PsgtrLoss"}:
        from .loss import PsgtrHungarianMatcher, PsgtrLoss

        return {
            "PsgtrHungarianMatcher": PsgtrHungarianMatcher,
            "PsgtrLoss": PsgtrLoss,
        }[name]
    if name in {"PsgtrForPanopticSceneGraphGeneration", "PsgtrOutput"}:
        from .modeling_psgtr import (
            PsgtrForPanopticSceneGraphGeneration,
            PsgtrOutput,
        )

        return {
            "PsgtrForPanopticSceneGraphGeneration": (
                PsgtrForPanopticSceneGraphGeneration
            ),
            "PsgtrOutput": PsgtrOutput,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
